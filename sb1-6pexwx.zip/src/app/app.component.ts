import { Component, ViewChild, ElementRef } from '@angular/core';
import { WebView } from '@nativescript/core';

@Component({
  selector: 'ns-app',
  templateUrl: './app.component.html',
})
export class AppComponent {
  @ViewChild('webView', { static: true }) webViewRef: ElementRef<WebView>;
  currentUrl: string = 'https://www.google.com';

  loadUrl(url: string) {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    this.currentUrl = url;
  }

  goBack() {
    if (this.webViewRef.nativeElement.canGoBack) {
      this.webViewRef.nativeElement.goBack();
    }
  }

  goForward() {
    if (this.webViewRef.nativeElement.canGoForward) {
      this.webViewRef.nativeElement.goForward();
    }
  }

  goHome() {
    this.loadUrl('https://www.google.com');
  }

  onLoadFinished(args) {
    const webView = args.object as WebView;
    this.currentUrl = webView.src;
  }
}